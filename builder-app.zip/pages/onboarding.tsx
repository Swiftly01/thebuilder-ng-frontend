import { useToast } from "@/context/ToastContext";
import { errorMessage } from "@/lib/http";
import { LoadingDots } from "@/components/ui/LoadingDots";
import { useState } from "react";
import { useRouter } from "next/router";
import {
    Briefcase,
    Cpu,
    Landmark,
    HeartPulse,
    GraduationCap,
    Sprout,
    TrendingUp,
    Compass,
    Globe,
    Lightbulb,
    Palette,
    Check,
} from "lucide-react";
import { accountApi } from "@/features/account/api";
import {
    Field,
    accent,
    control,
    primary,
    secondary,
} from "@/features/account/fields";

const choices = [
    ["Entrepreneurship", Briefcase],
    ["Technology", Cpu],
    ["FinTech", Landmark],
    ["HealthTech", HeartPulse],
    ["Education", GraduationCap],
    ["Agriculture", Sprout],
    ["Investment", TrendingUp],
    ["Careers", Compass],
    ["Diaspora", Globe],
    ["Innovation", Lightbulb],
    ["Creative Economy", Palette],
] as const;
export default function Onboarding() {
    const { toast } = useToast();
    const router = useRouter();
    const q = String(router.query.state || "");
    const [step, setStep] = useState(1);
    const [selected, setSelected] = useState<string[]>(
        q === "step1"
            ? ["FinTech"]
            : ["Entrepreneurship", "FinTech", "Diaspora"],
    );
    const [info, setInfo] = useState({ country: "", city: "", profession: "" });
    const [busy, setBusy] = useState(false);
    const toggle = (x: string) =>
        setSelected(
            selected.includes(x)
                ? selected.filter((v) => v !== x)
                : [...selected, x],
        );
    const finish = async () => {
        setBusy(true);
        try {
            await accountApi.saveOnboarding({ interests: selected, ...info });
            setStep(3);
        } catch (e) {
            // 409 means onboarding was already completed (e.g. a retry after a
            // successful submit whose response was lost). Treat it as success.
            const status = (e as { status?: number })?.status;
            if (status === 409) {
                setStep(3);
            } else {
                toast(errorMessage(e), "error");
            }
        } finally {
            setBusy(false);
        }
    };
    return (
        <div className="min-h-screen bg-[var(--surface-card)]">
            <header className="flex items-center justify-between border-b border-[var(--border)] px-4 py-4 md:px-8">
                <b className="font-display text-lg text-[var(--text-heading)]">
                    The Builder<span className="text-[var(--accent)]">.</span>
                </b>
                {step < 3 && (
                    <div className="flex w-60 items-center gap-3 text-xs font-semibold text-[var(--text-meta)]">
                        <span>Step {step} of 2</span>
                        <span className="h-1 flex-1 rounded bg-[var(--border)]">
                            <i
                                className="block h-full bg-[var(--accent)] transition-all"
                                style={{ width: step === 1 ? "50%" : "100%" }}
                            />
                        </span>
                    </div>
                )}
            </header>
            <main className="mx-auto flex max-w-[880px] flex-col gap-7 px-4 py-8 md:px-6 md:py-14">
                {step === 1 && (
                    <>
                        <Title
                            title="What do you want to read about?"
                            sub={
                                selected.length >= 3
                                    ? `${selected.length} selected. Add more, or continue.`
                                    : `${selected.length} of 3 selected · pick at least ${3 - selected.length} more`
                            }
                        />
                        <div
                            role="group"
                            aria-label="Interests"
                            className="grid grid-cols-2 gap-3 md:grid-cols-[repeat(auto-fill,minmax(190px,1fr))]"
                        >
                            {choices.map(([name, Icon]) => {
                                const on = selected.includes(name);
                                return (
                                    <button
                                        key={name}
                                        type="button"
                                        aria-pressed={on}
                                        onClick={() => toggle(name)}
                                        className={`relative flex min-h-[104px] flex-col justify-between rounded-xl p-4 text-left transition md:min-h-[120px] ${on ? "border-2 border-[var(--text-heading)] bg-[var(--surface-inverse)] text-[var(--text-on-inverse)]" : "border border-[var(--border)] text-[var(--text-heading)]"}`}
                                    >
                                        <Icon size={24} />
                                        <span className="font-semibold">
                                            {name}
                                        </span>
                                        {on && (
                                            <span className="absolute right-3 top-3 rounded-full bg-[var(--surface-card)] p-1 text-[var(--text-heading)]">
                                                <Check size={14} />
                                            </span>
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                        <div className="sticky bottom-0 flex items-center justify-between border-t border-[var(--border)] bg-[var(--surface-card)] py-4">
                            <button
                                onClick={() => router.push("/")}
                                className="text-sm text-[var(--text-meta)]"
                            >
                                Skip for now
                            </button>
                            <button
                                className={primary}
                                disabled={selected.length < 3}
                                onClick={() => setStep(2)}
                            >
                                Continue →
                            </button>
                        </div>
                    </>
                )}
                {step === 2 && (
                    <>
                        <Title
                            title="A little about you"
                            sub="Optional. It helps us show stories and opportunities near you."
                        />
                        <div className="grid max-w-[640px] gap-4 sm:grid-cols-2">
                            <Field label="Country">
                                <input
                                    className={control}
                                    value={info.country}
                                    onChange={(e) =>
                                        setInfo({
                                            ...info,
                                            country: e.target.value,
                                        })
                                    }
                                />
                            </Field>
                            <Field label="City">
                                <input
                                    className={control}
                                    placeholder="e.g. Lagos"
                                    value={info.city}
                                    onChange={(e) =>
                                        setInfo({
                                            ...info,
                                            city: e.target.value,
                                        })
                                    }
                                />
                            </Field>
                            <div className="sm:col-span-2">
                                <Field label="Profession">
                                    <input
                                        className={control}
                                        placeholder="e.g. Founder, engineer, student"
                                        value={info.profession}
                                        onChange={(e) =>
                                            setInfo({
                                                ...info,
                                                profession: e.target.value,
                                            })
                                        }
                                    />
                                </Field>
                            </div>
                        </div>
                        <div className="flex max-w-[640px] justify-between border-t border-[var(--border)] pt-4">
                            <button
                                className={secondary}
                                onClick={() => setStep(1)}
                            >
                                ← Back
                            </button>
                            <button
                                className={accent}
                                disabled={busy}
                                onClick={finish}
                            >
                                {busy ? <LoadingDots /> : "Finish"}
                            </button>
                        </div>
                    </>
                )}
                {step === 3 && (
                    <div
                        role="status"
                        className="flex min-h-[50vh] flex-col justify-center gap-4"
                    >
                        <h1 className="font-display text-[44px] font-extrabold text-[var(--text-heading)] md:text-7xl">
                            You’re all set
                        </h1>
                        <p className="text-lg">
                            We’ve tuned your account to{" "}
                            {selected.slice(0, 3).join(", ")}
                            {selected.length > 3
                                ? ` and ${selected.length - 3} more`
                                : ""}
                            .
                        </p>
                        <button
                            className={`${primary} w-fit`}
                            onClick={() => router.push("/account")}
                        >
                            Go to my feed →
                        </button>
                    </div>
                )}
            </main>
        </div>
    );
}
function Title({ title, sub }: { title: string; sub: string }) {
    return (
        <div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight text-[var(--text-heading)] md:text-[44px]">
                {title}
            </h1>
            <p aria-live="polite" className="mt-2 text-[var(--text-meta)]">
                {sub}
            </p>
        </div>
    );
}
